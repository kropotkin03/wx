from wx import *

class MyApp(App):
    def OnInit(self):
        f = Frame(None, -1, "Titulo")
        p = Panel(f)
        s = BoxSizer(VERTICAL)
        t1 = self.t1 = TextCtrl(p)
        t2 = self.t2 = TextCtrl(p)
        b = Button(p, -1, "Suma")
        r = self.r = StaticText(p)
        b.Bind(EVT_BUTTON, self.sumar)
        s.Add(t1)
        s.Add(t2)
        s.Add(b)
        s.Add(r)
        p.SetSizer(s)
        f.Show()

        return True

    def sumar(self, e):
        self.r.SetLabel(str(int(self.t1.Value) + int(self.t2.Value)))


app = MyApp()
app.MainLoop()

