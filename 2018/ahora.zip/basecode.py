from wx import *


class MyApp(App):
    def OnInit(self):

        return True


app = MyApp()
app.MainLoop()
